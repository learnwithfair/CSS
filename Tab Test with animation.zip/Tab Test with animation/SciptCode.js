let tabHeader = document.getElementsByClassName("tab_header")[0];
let tabIndicator = document.getElementsByClassName("tab_indicator")[0];
let tabBody = document.getElementsByClassName("tab_body")[0];
let tabsPane = tabHeader.getElementsByTagName("div");
let tabsImage = tabHeader.getElementsByTagName("img");

for(let i = 0; i<tabsPane.length ;i++){
    tabsPane[i].addEventListener("click",function(){
        tabHeader.getElementsByClassName("active")[0].classList.remove("active");
        tabsPane[i].classList.add("active");
        tabsImage[i].classList.add("active");
        tabBody.getElementsByClassName("active")[0].classList.remove("active");
        tabBody.getElementsByTagName("div")[i].classList.add("active");
         tabIndicator.style.left = `calc(calc(100% / 4) * ${i})`;
        
    });
}